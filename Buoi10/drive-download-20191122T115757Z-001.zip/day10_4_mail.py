import getpass
import smtplib
import ssl
from email.mime.text import MIMEText

stmp_server = 'smtp.gmail.com'
port = 465
from_email = 'lhhoangtv87@gmail.com'
to_email = 'lehuuhoang87@gmail.com'

message = 'Hello, test mail'
msg = MIMEText(message)
msg['to'] = to_email
msg['subject'] = 'Test send email'

context = ssl.create_default_context()

with smtplib.SMTP_SSL(stmp_server, port,  context=context) as server:
    password = getpass.getpass('Password:')
    server.login(from_email, password)
    server.sendmail(from_email, to_email, msg.as_string())
