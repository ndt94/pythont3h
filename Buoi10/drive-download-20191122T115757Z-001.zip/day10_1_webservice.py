import json
import requests

url = 'http://api.openweathermap.org/data/2.5/weather?id=1581129&units=metric&appid=d6477696b63c2e661af64eead58c11d9'

req = requests.get(url)
text = req.text
# print(text)


result = json.loads(text)
# print(result)
print('Nhiệt độ:', result['main']['temp'])
