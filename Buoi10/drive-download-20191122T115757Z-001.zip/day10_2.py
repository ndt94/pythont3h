import json
import requests

url = 'https://translation.googleapis.com/language/translate/v2?key=AIzaSyBSut2ax6ct7NAMGELpAZ_bRxNVuDS-ZRU'

params = {
    'q': "What's the weather like?",
    'source': 'en',
    'target': 'vi',
    'format': 'text'
}
req = requests.post(url, data=json.dumps(params))
result = json.loads(req.text)

print("What's the weather like? >>>>>",
      result['data']['translations'][0]['translatedText'])
