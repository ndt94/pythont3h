import requests
import json
import base64

file = 'sample1.jpg'
with open(file, 'rb') as f:
    base64data = base64.b64encode(f.read())
url = 'https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBSut2ax6ct7NAMGELpAZ_bRxNVuDS-ZRU'

params = {
    "requests": [
        {
            "image": {"content": base64data.decode()},
            "features": [{"type": "DOCUMENT_TEXT_DETECTION"}]
        }
    ]
}

req = requests.post(url, data=json.dumps(params))
with open('result.json', 'w', encoding='utf-8') as f:
    f.write(req.text)
result = json.loads(req.text)
print(result["responses"][0]["fullTextAnnotation"]["text"])
